local neonColors = {["red"] = 14399, ["blue"] = 14400, ["green"] = 14401, ["yellow"] = 14402, ["pink"] = 14403, ["white"] = 14404}
function attachNeon(color, vehicle, zDis)
	if not color then return end
	if not vehicle then return end
	if not neonColors[color] then return end
	if hasNeon(vehicle) then return false end
	local neonElement = createElement("neon")
	local x, y, z = getElementPosition(vehicle)
	local rx, ry, rz = getElementRotation(vehicle)	
	local vHandling = getVehicleHandling(vehicle)
	local rDis = vHandling["suspensionLowerLimit"]
	local neon1 = createObject(neonColors[color], x, y, z)
	setElementRotation(neon1, rx, ry, rz)
	local neon2 = createObject(neonColors[color], x, y, z)
	setElementRotation(neon2, rx, ry, rz)
	attachElements(neon1, vehicle, 0.8, 0, -(zDis+rDis))
	attachElements(neon2, vehicle, -0.8, 0, -(zDis+rDis))
	local function destroyNeon()
		if not getElementData(vehicle, "neon") then return end
		local neonEl = getElementData(vehicle, "neon")
		local neonElNs = getElementData(neonEl, "neon")
		destroyElement(neonElNs[1])
		destroyElement(neonElNs[2])
		destroyElement(neonEl)		
	end	
	addEventHandler("onElementDestroy", vehicle, destroyNeon)
	setElementData(neonElement, "neon", {neon1, neon2})
	setElementData(neonElement, "vehicle", vehicle)
	setElementData(vehicle, "neon", neonElement)
	setElementData(neonElement, "color", color)	
	return neonElement
end
addEvent("createNeon", true)
addEventHandler("createNeon", getRootElement(), attachNeon)
function setNeonColor(vehicle, color)
	if not color then return end
	if not vehicle then return end
	if not neonColors[color] then return end
	if not getElementData(vehicle, "neon") then return end
	local neonElement = getElementData(vehicle, "neon")
	local neons = getElementData(neonElement, "neon")	
	local neon1aO = {getElementAttachedOffsets(neons[1])}
	local neon2aO = {getElementAttachedOffsets(neons[2])}
	local x, y, z = getElementPosition(vehicle)
	local rx, ry, rz = getElementRotation(vehicle)	
	destroyElement(neons[1])
	destroyElement(neons[2])
	local neon1 = createObject(neonColors[color], x, y, z)
	setElementRotation(neon1, rx, ry, rz)
	local neon2 = createObject(neonColors[color], x, y, z)
	setElementRotation(neon2, rx, ry, rz)
	attachElements(neon1, vehicle, unpack(neon1aO))
	attachElements(neon2, vehicle, unpack(neon2aO))		
	setElementData(neonElement, "neon", {neon1, neon2})
	setElementData(neonElement, "vehicle", vehicle)
	setElementData(vehicle, "neon", neonElement)
	setElementData(neonElement, "color", color)	
	return neonElement
end
function getNeonColor(vehicle)
	if not vehicle then return end
	if hasNeon(vehicle) then
		return getElementData(getElementData(vehicle, "neon"), "color")
	else
		return false
	end
end
function addNeon(vehicle, color)
	if not vehicle then return end
	local controller = getVehicleController(vehicle)
	local occupants = getVehicleOccupants(vehicle)
	if not controller then
		if #occupants >= 1 then
			for seat, occupant in pairs(occupants) do
				if getElementType(occupant) == "player" then
				outputChatBox("Triggered Neon Event to random Vehicle Occupant")
				return triggerClientEvent(occupant, "createNeonS", getRootElement(), color, vehicle)	
				end
			end
		else
			local x, y, z = getElementPosition(vehicle)
			local aCol = createColSphere(x, y, z, 300)
			local players = getElementsWithinColShape(aCol)
			destroyElement(aCol)
			if #players >= 1 then	
				outputChatBox("Triggered Neon Event to random Player near the Vehicle")
				return triggerClientEvent(players[math.random(1, #players)], "createNeonS", getRootElement(), color, vehicle)
			end
		end
	else
		outputChatBox("Triggered Neon Event to vehicle's controller")
		return triggerClientEvent(controller, "createNeonS", getRootElement(), color, vehicle)
	end
end
function hasNeon(vehicle)
	if not vehicle then return end
	if getElementData(vehicle, "neon") then
		return true
	else
		return false
	end
end
function removeNeon(vehicle)
	if not vehicle then return end
	if hasNeon(vehicle) == false then return end
	local neonElement = getElementData(vehicle, "neon")
	local neonTubes = getElementData(neonElement, "neon")
	destroyElement(neonTubes[1])
	destroyElement(neonTubes[2])
	removeElementData(vehicle, "neon")
	destroyElement(neonElement)
	return true
end
addCommandHandler("neon", function(source, cmd, color)
	if not color then return end
	if not isPedInVehicle(source) then return end
	addNeon(getPedOccupiedVehicle(source), color)	
end)
addCommandHandler("neoncolor", function(source, cmd, color)
	if not color then return end
	if not isPedInVehicle(source) then return end
	setNeonColor(getPedOccupiedVehicle(source), color)
end)
addCommandHandler("neonremove", function(source, cmd)
	if not isPedInVehicle(source) then return end
	removeNeon(getPedOccupiedVehicle(source))
end)